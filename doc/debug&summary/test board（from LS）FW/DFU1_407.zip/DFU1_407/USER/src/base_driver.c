/**
  ******************************************************************************
  * @file    base_driver.c
  * $Author: wdluo $
  * $Revision: 229 $
  * $Date:: 2014-05-13 13:00:02 +0800 #$
  * @brief   ��Ϣ����.
  ******************************************************************************
  * @attention
  *
  *<h3><center>&copy; Copyright 2009-2012, EmbedNet</center>
  *<center><a href="http:\\www.embed-net.com">http://www.embed-net.com</a></center>
  *<center>All Rights Reserved</center></h3>
  * 
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/ 
#include "stm32f4xx.h"
#include "base_driver.h"

/**
  * @brief  ����LED����
  * @param  ��
  * @retval ��
  */
//void LED_Config(void)
//{
//	GPIO_InitTypeDef  GPIO_InitStructure;

//  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOH | RCC_AHB1Periph_GPIOI, ENABLE);//ʹ��GPIOHʱ��

//  //GPIOH2,H3��ʼ������
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;//LED0��LED1��ӦIO��
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
//  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
//  GPIO_Init(GPIOH, &GPIO_InitStructure);//��ʼ��GPIO
//	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_10;//LED0��LED1��ӦIO��
//	GPIO_Init(GPIOI, &GPIO_InitStructure);//��ʼ��GPIO
//	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;				//rst
//	GPIO_Init(GPIOH, &GPIO_InitStructure);
//	
//	GPIO_SetBits(GPIOH,GPIO_Pin_5);
//	
//	GPIO_ResetBits(GPIOH,GPIO_Pin_2 | GPIO_Pin_3);//GPIOH2,H3���õͣ�����
//	
//	GPIO_ResetBits(GPIOI,GPIO_Pin_8 | GPIO_Pin_10);//GPIOI8,I10���õͣ�����
//}
/**
  * @brief  ����LED
  * @param  LED_R,LED_G,LED_B
  * @retval ��
  */
void LED_On(uint16_t led)
{
  if(LED_B == led){
    GPIO_SetBits(GPIOH,LED_B);
  }else{
    GPIO_SetBits(GPIOH,led);
  }
}

/**
  * @brief  Ϩ��LED
  * @param  LED_R,LED_G,LED_B
  * @retval ��
  */
void LED_Off(uint16_t led)
{
  if(LED_B == led){
    GPIO_ResetBits(GPIOH,LED_B);
  }else{
    GPIO_ResetBits(GPIOH,led);
  }
}


