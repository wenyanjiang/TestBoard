/**
  ******************************************************************************
  * @file    led.h
  * $Author: wdluo $
  * $Revision: 229 $
  * $Date:: 2014-05-13 13:00:02 +0800 #$
  * @brief   ��Ϣ����.
  ******************************************************************************
  * @attention
  *
  *<h3><center>&copy; Copyright 2009-2012, EmbedNet</center>
  *<center><a href="http:\\www.embed-net.com">http://www.embed-net.com</a></center>
  *<center>All Rights Reserved</center></h3>
  * 
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#ifndef __BASE_DRIVER_H
#define __BASE_DRIVER_H


#define LED_Y   GPIO_Pin_2 //PH2
#define LED_B   GPIO_Pin_3 //PH3

//void LED_Config(void);
void LED_On(uint16_t led);
void LED_Off(uint16_t led);

#endif
